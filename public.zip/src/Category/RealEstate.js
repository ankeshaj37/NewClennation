import React, { useState, useEffect } from 'react'
import { db } from '../component/firebase'
import 'react-tabs/style/react-tabs.css';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';


const Programming = () => {

  const [first, setfirst] = useState([])
  const navigate = useNavigate()
  useEffect(() => {
    db.collection('cetegory').doc('MA8P3Re6z9Qy4V1silHS').collection('Real Estate').onSnapshot(tap => (
      setfirst(tap.docs.map((e) => (e.data())))
    ))
  }, [])
  const book = () => {
    navigate('/form')
  }

  console.log(first);
  return (
    <div>
      <Helmet>
        <title>Get Low Cost RealEstate Agents Near Me in Mumbai</title>
        <meta name="description" content="Services for Mumbai Real EstateReal estate agents assist in the purchase, sale, allotment, renting or 
          valuation of real estate, process real estate contracts, leases and other related paperwork for residential property in Mumbai"/>
        <meta name="keywords" content="Services for Mumbai Real EstateReal estate agents assist in the purchase, sale, allotment, renting or
          valuation of real estate, process real estate contracts, leases and other related paperwork for residential property in Mumbai"/>
        <meta name="robots" content="index, follow" />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="language" content="English" />
      </Helmet>
      <div className='container'>
        {first.map((e) => (
          <>
            <div className=' eee row'>
              <div className='ass col-lg-6'>
                <div className='imgedivvv'>
                  <img className='imagesss' src={e.image}></img>
                </div>

              </div>
              <div className='col-lg-6'>
                <div><h3>{e.title}</h3></div>
                <div><details>
                  <summary>Details</summary>
                  <h6>{e.infor}</h6>
                </details></div>
                <br />
                <div><h5>₹ {e.Price}</h5></div>
                <br />


                <a href={e.address} target="_blank" className='linku'><div className='locdiv'><div className='shsh'><img className='loca'
                  src='https://img.icons8.com/ios-filled/512/place-marker.png' /></div></div></a><div className='buttdiv'>
                  <button className="buttdiv"><a className="buttdiv" href={"tel:" + e.mobile}>Call</a></button>
                  <button className='buttdiv' onClick={book}>Enquiry</button>
                </div>
              </div>

            </div>
          </>
        ))}
      </div>



    </div>
  )
}

export default Programming
