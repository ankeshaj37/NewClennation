import React from 'react'

const Privecy = () => {
  return (
    <div className='condition'>
      <h1> Privacy Policy </h1>
      <br></br>
      <br></br>

<h3>Our Information</h3>
<br></br>
We strive to provide you the option to opt-out when we send you marketing and promotional content via email. utilising 
the opt-out instructions included in such emails, you can stop receiving such messages.
<br></br>
<br></br>
You are aware of and agree that Your desire to opt out may not take effect for up to 20 business days. Please be aware 
that we might still email you.regarding your user account or any desired services or obtained through cleannation.in
<br></br>
<br></br>
<h3>
Our Services</h3>
<br></br>

All the services we occasionally offer through our website https://www.cleannation.in that you might be interested in
you must include your name, home and work addresses, email, date of birth, and other personal information.
<br></br>
<br></br>
This Policy pertains to Personal Information as revealed on the Platform and is used for three broad purposes:
to personalise the content you view, to carry out your requests for specific services, and to administer the Platform.
<br></br>
<br></br>
For the operation of our Website, we may work with a variety of external organisations (third party service providers).
 For instance, we might employ third parties to host our website, manage different features that are made available on it, 
send emails, analyse data, give search results and connections, and help with purchase fulfilment.
<br></br>
<br></br>
 For the services offered through our website to function, some of these third parties may require access to your information.
 These service providers will only be given access to information when they truly need it, and they will only be 
allowed to use it for the stated purposes.
<br></br>
<br></br>
<h3>
Account Information</h3>
<br></br>
Since we don't have any credit card data on file, we don't have access to it. If you are a business client of ours, It's possible
 that we and you have a non-disclosure agreement in place for sensitive data. This Rule shall not in any way impact such a deal.

 <br></br>
 <br></br>
You can change your account information and preferences—including whether you want us to contact you—at any time. about brand-new 
services. Additionally, we shall make reasonable efforts to confirm your identification in order to safeguard your privacy and 
security.prior to allowing access or making changes.

<br></br>
<br></br>

<h3>Rights</h3>
<br></br>
We ask that you examine our privacy policy frequently because we update it frequently. It is crucial that the personal information 
we have on you is accurate and up to date. If your personal information changes while you are a customer of ours, kindly let us know.
<br></br>
<br></br>

Only one or more of the following situations will result in us sharing personal data: - If we have your consent or are deemed to
 have your consent to do so; - If we are required to do so by law, including court orders.
 <br></br>
 <br></br>
<h3>cookees</h3>
<br></br>
In order to provide you with a flawless user experience, we utilise cookies to help us differentiate you from other Platform 
users, comprehend and remember your choices for subsequent visits, keep track of adverts, and compile aggregate statistics about
 site traffic and site activity.
 <br></br>
 <br></br>
  To help us understand our website users better we might get in touch with third-party service 
 providers. The information gathered on our behalf may only be used by these service providers to support and enhance our business
 operations.


    </div>
  )
}

export default Privecy
